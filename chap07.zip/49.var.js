// let sum = 0;

function add(a, b) {

    let sum = 0;

    sum = a + b;
    return sum;
}

add(1, 2);
console.log(sum);
