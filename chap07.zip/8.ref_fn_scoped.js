//var 생략 가능
for (var j = 0; j < 10; j++) {
  console.log("j", j);
}
console.log("after loop j is ", j); // after loop j is 10
