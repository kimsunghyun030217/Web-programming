console.log("Your\tre right!");
console.log("Your\nre right!");
console.log("Your're right!"); // \'
console.log("Your\'re right!"); // \'
console.log('Your"re right!'); // \"
console.log("Your\\re right!");
console.log("Your\u005Cre right!");
