var x = 5;
var x = 6; // 가능
x = 7;
let y = 5;
// let y = 6; //불가능
y = 6;
const z = 5;
//const z = 6; //불가능
// z = 6;

console.log(x);
console.log(y);
console.log(z);
