console.log(`25 + 30 = ${25 + 30}`);
console.log(`올해는 ${new Date().getFullYear()}년 입니다.`);

var x = 10;
console.log("x = %d", x);
console.log(`x = ${x}`);
