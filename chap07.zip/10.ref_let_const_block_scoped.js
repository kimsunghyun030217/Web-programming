if (true) {
  var x = 5; // 전역변수
  // let x = 5; // block scoped
  // const x = 5; // block scoped
}

console.log(x);
